public class ProblemSet2 {

    public static void main(String[] args) {
        
        // 1. If statement
        // Write an if-else statement that checks if a number is positive, negative, or zero.
        // Print "Positive", "Negative", or "Zero" based on the condition.
        
        int number = -5;

        // Put your code here:

        // 2. Nested if statements
        // Write a program that checks if a person is eligible to vote.
        // A person is eligible if they are 18 or older and a citizen.
        
        int age = 20;
        boolean isCitizen = true;

        // Put your code here:


        // 3. Switch statement
        // Write a switch statement that prints the name of a day based on a given integer (1-7).
        // For example, 1 = "Sunday", 2 = "Monday", ..., 7 = "Saturday".
        
        int dayOfWeek = 3;

        // Put your code here:

        // 4. For loop
        // Write a for loop that prints all even numbers between 1 and 10.

        // Put your code here:


        // 5. Nested for loops
        // Write a nested for loop to print a multiplication table for numbers 1 through 5.

        // Put your code here:
        

        // 6. While loop
        // Write a while loop that prints the numbers from 1 to 5.

        // Put your code here:
        

        // 7. Do-while loop
        // Write a do-while loop that samples a random number between 1 to 10.
        // The loop should continue until the number 7 is sampled.

        // Put your code here:

        // 8. Convert decimal to binary
        // Write a program that converts an integer to its binary representation using a loop.
        // Example: If the input is 5, the output should be "101".
        
        int decimal = 19;
        String binary = "";

        // Put your code here:

        // 9. Enhanced for loop
        // Write a for loop that calculates the sum of all elements which are divisible by 3 up to 50.

        // Put your code here:

        // 10. Using break in a loop
        // Write a for loop that prints numbers from 1 to 10, but stops if it encounters the number 5.

        // Put your code here:
    }
}