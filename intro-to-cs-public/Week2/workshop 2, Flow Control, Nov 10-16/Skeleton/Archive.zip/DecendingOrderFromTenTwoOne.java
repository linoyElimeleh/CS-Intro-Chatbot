public class DecendingOrderFromTenTwoOne {
    public static void main(String[] args) {
        
    }
}
