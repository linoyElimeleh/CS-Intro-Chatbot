public class IsTwoDigitNumber {
    public static void main(String[] args) {
        
    }
}
