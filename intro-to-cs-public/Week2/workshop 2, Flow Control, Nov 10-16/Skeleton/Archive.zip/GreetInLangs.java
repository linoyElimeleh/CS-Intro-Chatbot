public class GreetInLangs {
    /**
     * Hebrew                    -> "Shalom" 
     * English (also as Default) -> "Hello"
     * German                    -> "Guten Tag"
     * French                    -> "Bonjour"
     * Italian                   -> "Ciao"
     * Spanish                   -> "Hola"
     */

    public static void main(String[] args) {
     
    }
}
