public class isFirstCharInArgDigit {
    public static void main(String[] args) {
      
    }
}
