public class AbsoluteValue {

    public static void main(String[] args) {
        
    }
}