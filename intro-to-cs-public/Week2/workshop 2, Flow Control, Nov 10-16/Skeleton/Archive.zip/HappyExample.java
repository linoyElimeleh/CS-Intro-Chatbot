public class HappyExample {
    public static void main(String[] args) {
        String word = args[0];
        int n = Integer.parseInt(args[1]);

        for (int i = 0; i < n; i++) {
            System.out.print(word);
        } 
        System.out.println();
    }
}
