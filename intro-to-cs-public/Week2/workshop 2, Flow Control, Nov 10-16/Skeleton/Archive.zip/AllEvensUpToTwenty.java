public class AllEvensUpToTwenty {
    public static void main(String[] args) {
       
    }
}
