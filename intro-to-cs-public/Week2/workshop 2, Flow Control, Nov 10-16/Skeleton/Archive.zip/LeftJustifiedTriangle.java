public class LeftJustifiedTriangle {

    public static void main(String[] args) {
        
    }
}