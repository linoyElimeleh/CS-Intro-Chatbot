public class ExampleConditions {
      public static void main(String[] args) {
        int count = 50;
        if (count < 100) {
            System.out.println("less than 100");
        } 
    }  
}
