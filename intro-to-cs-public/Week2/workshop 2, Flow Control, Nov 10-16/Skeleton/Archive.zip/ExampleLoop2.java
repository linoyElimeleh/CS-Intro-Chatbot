public class ExampleLoop2 {
    public static void main(String[] args) {
        int count = 50;
        while (count < 10) {
            count = count + 1;
            System.out.println(count);
        }
    }
}
