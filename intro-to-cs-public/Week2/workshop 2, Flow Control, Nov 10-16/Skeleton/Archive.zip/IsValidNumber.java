public class IsValidNumber {
    public static void main(String[] args) {
        
    }
}
