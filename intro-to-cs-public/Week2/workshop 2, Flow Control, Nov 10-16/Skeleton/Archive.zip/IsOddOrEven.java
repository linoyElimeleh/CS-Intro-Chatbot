public class IsOddOrEven {
    public static void main(String[] args) {
       
    }
}
