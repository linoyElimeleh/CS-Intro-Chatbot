public class FirstTenPowOfTwo {

    public static void main(String[] args) {
        
    }
}