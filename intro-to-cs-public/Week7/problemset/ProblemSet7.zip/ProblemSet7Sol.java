public class ProblemSet7Sol {
    // In this problem set you cant use any loops,
    // You should use recursion only
    public static void main(String[] args) {
        printTriangleOfStars(5);
    }
    /**
     * The function printLineOfStars recieves a non negative integer number
     * And prints a line of '*' in the size of n then moves to next line 
     * Example: n = 5 -> *****
     */
    public static void printLineOfStars(int n){
        if (n == 0){
            System.out.println();
            return;
        }
        System.out.print('*');
        printLineOfStars(n - 1);
    }

    /**
     * The function printTriangleOfStars recieves a non negative integer number
     * And prints a line of '*' in the size of n lines for every 0 < num < n then moves to next line
     * Such that first line printed is size 1, second is size 2, ... , last is size n
     * Example: (Dont need spaces in start just for clarification, same for all ex)
     * n = 5 -> 
     *      *
     *      **
     *      ***
     *      ****
     *      *****
     */
    public static void printTriangleOfStars(int n){
        if (n == 0){
            return;
        }
        printTriangleOfStars(n-1);
        printLineOfStars(n);
        
    }

    /**
     * The function printUpsideDownTriangleOfStars recieves a non negative integer number
     * And prints a line of '*' in the size of n lines for every 0 < num < n then moves to next line,
     * Such that first line printed is size n, second is size n-1, ... , last is size 1
     * Example: 
     * n = 5 -> 
     *      *****
     *      ****
     *      ***
     *      **
     *      * 
     */
    public static void printUpsideDownTriangleOfStars(int n){
        if (n == 0){
            return;
        }
        printLineOfStars(n);
        printTriangleOfStars(n-1);
    }

    /**
     * The function printTriangleOfStars recieves a couple non negative integer numbers, n,m
     * And prints m lines of size n then moves to next line and in the end 
     * prints next line
     * Example: 
     * n = 5, m = 4 -> 
     *      *****
     *      *****
     *      *****
     *      *****
     */
    public static void printRectangleOfStars(int n, int m){
        if (m == 0) {
            return;
        }
        printLineOfStars(n);
        printRectangleOfStars(n, m - 1);
    }

    /**
     * The function printTriangleOfStars recieves a non negative integer numbers, n
     * And prints m lines of size n then moves to next line and in the end 
     * prints next line
     * Example: 
     * n = 5-> 
     *      *****
     *      *****
     *      *****
     *      *****
     *      *****
     */
    public static void printSquareOfStars(int n){
        printRectangleOfStars(n, n); // altenative.. need to build helper function which does the same  
    }
}
