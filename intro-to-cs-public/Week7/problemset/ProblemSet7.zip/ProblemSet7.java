public class ProblemSet7 {
    // In this problem set you cant use any loops,
    // You should use recursion only

    /**
     * The function printLineOfStars recieves a non negative integer number
     * And prints a line of '*' in the size of n then moves to next line 
     * Example: n = 5 -> *****
     */
    public static void printLineOfStars(int n){
        
    }

    /**
     * The function printTriangleOfStars recieves a non negative integer number
     * And prints a line of '*' in the size of n lines for every 0 < num < n then moves to next line
     * Such that first line printed is size 1, second is size 2, ... , last is size n
     * Example: (Dont need spaces in start just for clarification, same for all ex)
     * n = 5 -> 
     *      *
     *      **
     *      ***
     *      ****
     *      *****
     */
    public static void printTriangleOfStars(int n){
        
    }

    /**
     * The function printUpsideDownTriangleOfStars recieves a non negative integer number
     * And prints a line of '*' in the size of n lines for every 0 < num < n then moves to next line,
     * Such that first line printed is size n, second is size n-1, ... , last is size 1
     * Example: 
     * n = 5 -> 
     *      *****
     *      ****
     *      ***
     *      **
     *      * 
     */
    public static void printUpsideDownTriangleOfStars(int n){
        
    }

    /**
     * The function printTriangleOfStars recieves a couple non negative integer numbers, n,m
     * And prints m lines of size n then moves to next line and in the end 
     * prints next line
     * Example: 
     * n = 5, m = 4 -> 
     *      *****
     *      *****
     *      *****
     *      *****
     */
    public static void printRectangleOfStars(int n, int m){
        
    }

    /**
     * The function printTriangleOfStars recieves a non negative integer numbers, n
     * And prints m lines of size n then moves to next line and in the end 
     * prints next line
     * Example: 
     * n = 5-> 
     *      *****
     *      *****
     *      *****
     *      *****
     *      *****
     */
    public static void printSquareOfStars(int n, int m){
        
    }
}
