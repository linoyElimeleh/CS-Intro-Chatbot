public class ProblemSet6 {
    public static void main(String[] args) {
        
    }

    /**
     *  reads line from './text.txt' then print it to screen 
     */
    public static void printHelloWorld(){
        
    }

    /**
     *  reads from './text.txt' then put it in upper case then put in a new file name 'upperText.txt'
     */
    public static void helloWorldToFile(){

    }

    /**
     *  reads from keyboard a word then put it in and then put in a new file name 'fromKeyboard.txt'
     */
    public static void helloWorldFromKeyboardToFile(){

    }
    
    /**
     *  reads one word at a time from './text.txt' then print it to screen 
     */
    public static void printHelloWorldSeperate(){

    }
}

