public class ProblemSet6Sol {
    public static void main(String[] args) {
        
    }

    /**
     *  reads line from './text.txt' then print it to screen 
     */
    public static void printHelloWorld(){
        In in = new In("text.txt");
        while (!in.isEmpty()) {
            String s = in.readLine();
            System.out.println(s);
        }
    }

    /**
     *  reads from './text.txt' then put it in upper case then put in a new file name 'upperText.txt'
     *  Run: 1. Javac ProblemSet6Sol.java
     *       2. Java PropblemSetSol.java > upperText.txt
     */
    public static void helloWorldToFile(){
        In in = new In("text.txt");
        while (!in.isEmpty()) {
            String s = in.readLine();
            StdOut.println(s.toUpperCase());            
        }
    }


    /**
     *  reads from keyboard a line then put it in and then put in a new file name 'fromKeyboard.txt'
     *  Run: 1. Javac ProblemSet6Sol.java
     *       2. Java PropblemSetSol.java > fromKeyboard.txt
     */
    public static void helloWorldFromKeyboardToFile(){
        In in = new In();
        while (!in.isEmpty()) {
            String s = in.readLine();
            StdOut.println(s);            
        }

    }
    
    /**
     *  reads one word at a time from './text.txt' then print it to screen 
     */
    public static void printHelloWorldSeperate(){
        In in = new In("text.txt");
        while (!in.isEmpty()) {
            String s = in.readString();
            System.out.println(s);
        }
    }   
    

}
